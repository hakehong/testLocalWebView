var oDiv = document.getElementById('b')
oDiv.addEventListener('click', function () {
    alert('aaa')
})